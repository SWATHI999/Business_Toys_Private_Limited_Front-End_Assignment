# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from django.core.validators import RegexValidator
import datetime
# Create your models here.
class user_profile_details(models.Model):
     user_id=models.AutoField(primary_key=True)
     firstname=models.CharField(max_length=30)
     lastname=models.CharField(max_length=30)
     username=models.CharField(max_length=30)
     city=models.CharField(max_length=30)
     birthdate= models.DateField( default=datetime.date.today)
     website=models.CharField(max_length=30)
     email=models.EmailField(max_length=254)
     country=models.CharField(max_length=30)
     interests=models.CharField(max_length=30)
     phone_regex = RegexValidator(regex=r'^\+?1?\d{9,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
     phonenumber = models.CharField(validators=[phone_regex],max_length=17)
     password = models.CharField(max_length=30,default="abc")
     profilephoto=models.ImageField()

