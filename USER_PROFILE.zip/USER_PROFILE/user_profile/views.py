# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import *
from .models import *
from django.http import *

# Create your views here.
def home(request):
	template = loader.get_template('navbar.html')
    	context = {}
	return HttpResponse(template.render(context, request))
def register(request):
	if request.method == 'POST':
		user=user_profile_details(firstname=request.POST.get('firstname'),lastname=request.POST.get('lastname'),username=request.POST.get('username'),city=request.POST.get('city'),birthdate=request.POST.get('birthdate'),website=request.POST.get('website'),country=request.POST.get('country'),interests=request.POST.get('interests'),phonenumber=request.POST.get('phonenumber'),profilephoto=request.FILES['profilephoto'],email=request.POST.get('email'),password=request.POST.get('password'))
		user.save()
		template = loader.get_template('login.html')
    		context = {'success':1}
		return HttpResponse(template.render(context, request))
	else:	
		template = loader.get_template('register.html')
    		context = {}
		return HttpResponse(template.render(context, request))
def login(request):
	if request.method == 'POST':
		if user_profile_details.objects.get(username=request.POST.get('username')) and user_profile_details.objects.get(username=request.POST.get('username')).password==request.POST.get('password'):
			request.session['username']=request.POST.get('username')
			users=user_profile_details.objects.get(username=request.session['username'])
			template = loader.get_template('home.html')	
    			context = {'success':1,'user_details':users}
			return HttpResponse(template.render(context, request))		
		else:
			template = loader.get_template('login.html')
    			context = {'success':0}
			return HttpResponse(template.render(context, request))
	else:
		template = loader.get_template('login.html')
    		context = {'success':2}
		return HttpResponse(template.render(context, request))	
def index(request):
	users=user_profile_details.objects.get(username=request.session['username'])
	template = loader.get_template('home.html')	
    	context = {'user_details':users}
	return HttpResponse(template.render(context, request))	
	
